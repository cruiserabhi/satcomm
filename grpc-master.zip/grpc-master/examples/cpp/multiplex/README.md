# gRPC C++ Multiplexing Example

[This example](https://github.com/grpc/grpc/tree/master/examples/cpp/multiplex) shows how to use a single connection to send multiple concurrent
asynchronous requests to different services. It also demonstrates multiple
sharing the same server connection.
